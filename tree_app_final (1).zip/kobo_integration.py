import streamlit as st
# Note: No st.set_page_config() here as it's already in app.py
import requests
import json
import time
import pandas as pd
import sqlite3
import qrcode
from io import BytesIO
import base64
import os
from pathlib import Path
import re

# KoBo Toolbox configuration
KOBO_API_URL = "https://kf.kobotoolbox.org/api/v2"
KOBO_API_TOKEN = "your_kobo_api_token"  # Replace with your actual token
KOBO_ASSET_ID = "your_asset_id"  # Replace with your actual asset ID

# Database configuration
BASE_DIR = Path(__file__).parent if "__file__" in locals() else Path.cwd()
DATA_DIR = BASE_DIR / "data"
SQLITE_DB = DATA_DIR / "trees.db"
QR_CODE_DIR = DATA_DIR / "qr_codes"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True, parents=True)
QR_CODE_DIR.mkdir(exist_ok=True, parents=True)

def get_kobo_form_url():
    """
    Get the URL for the KoBo form that users will fill out.
    This could be either the public form URL or an embedded form URL.
    """
    # For a public form, the URL would typically look like:
    # https://ee.kobotoolbox.org/x/ASSET_ID
    return f"https://ee.kobotoolbox.org/x/{KOBO_ASSET_ID}"

def launch_kobo_form():
    """
    Launch the KoBo form for tree planting.
    Returns the URL to the form.
    """
    form_url = get_kobo_form_url()
    
    # Display instructions and form link
    st.markdown("""
    ### Plant a Tree with KoBo Toolkit
    
    You'll be redirected to our tree planting form where you can:
    - Enter tree details
    - Capture planting location coordinates
    - Submit your tree planting information
    
    After submission, you'll receive a unique tree ID and QR code.
    """)
    
    # Create a button that will open the KoBo form in a new tab
    if st.button("Open Tree Planting Form", key="open_kobo_form"):
        # Use JavaScript to open the form in a new tab
        js = f"""
        <script>
        window.open('{form_url}', '_blank').focus();
        </script>
        """
        st.markdown(js, unsafe_allow_html=True)
        
        # Set session state to indicate form has been launched
        st.session_state.kobo_form_launched = True
        
        # Provide instructions for after form completion
        st.info("After completing the form, return to this page and click 'I've Completed the Form' below.")
        
        if st.button("I've Completed the Form", key="form_completed"):
            st.session_state.check_for_submission = True
    
    return form_url

def get_recent_kobo_submissions(hours=24):
    """
    Retrieve recent submissions from KoBo Toolbox API.
    
    Args:
        hours: Number of hours to look back for submissions
        
    Returns:
        List of submission data dictionaries
    """
    headers = {
        "Authorization": f"Token {KOBO_API_TOKEN}",
        "Content-Type": "application/json"
    }
    
    # Calculate timestamp for filtering (current time - hours)
    import datetime
    time_filter = datetime.datetime.now() - datetime.timedelta(hours=hours)
    time_filter_str = time_filter.isoformat()
    
    try:
        # Get submissions with time filter
        response = requests.get(
            f"{KOBO_API_URL}/assets/{KOBO_ASSET_ID}/data/",
            headers=headers,
            params={"query": json.dumps({"_submission_time": {"$gte": time_filter_str}})}
        )
        
        if response.status_code == 200:
            return response.json().get("results", [])
        else:
            st.error(f"Failed to retrieve KoBo submissions: {response.text}")
            return []
    except Exception as e:
        st.error(f"Error connecting to KoBo Toolbox: {str(e)}")
        return []

def map_kobo_to_database_fields(kobo_data):
    """
    Map KoBo form fields to database fields.
    
    Args:
        kobo_data: Dictionary containing KoBo form submission
        
    Returns:
        Dictionary with mapped fields for database insertion
    """
    # This mapping should be adjusted based on your actual KoBo form fields
    # and database schema
    mapped_data = {
        "institution": kobo_data.get("institution", ""),
        "local_name": kobo_data.get("local_name", ""),
        "scientific_name": kobo_data.get("scientific_name", ""),
        "student_name": kobo_data.get("student_name", ""),
        "date_planted": kobo_data.get("date_planted", ""),
        "tree_stage": kobo_data.get("tree_stage", "Seedling"),
        "rcd_cm": float(kobo_data.get("rcd_cm", 0)),
        "dbh_cm": float(kobo_data.get("dbh_cm", 0)),
        "height_m": float(kobo_data.get("height_m", 0)),
        "latitude": float(kobo_data.get("_geolocation", [0, 0])[0]),
        "longitude": float(kobo_data.get("_geolocation", [0, 0])[1]),
        "status": "Alive",
        "country": kobo_data.get("country", ""),
        "county": kobo_data.get("county", ""),
        "sub_county": kobo_data.get("sub_county", ""),
        "ward": kobo_data.get("ward", ""),
        "adopter_name": None,
        "last_monitored": kobo_data.get("_submission_time", ""),
        "monitor_notes": kobo_data.get("notes", "")
    }
    
    return mapped_data

def generate_tree_id(institution_name):
    """
    Generate a unique tree ID based on institution name and existing IDs.
    
    Args:
        institution_name: Name of the institution
        
    Returns:
        Unique tree ID string
    """
    prefix = institution_name[:3].upper()
    
    conn = sqlite3.connect(SQLITE_DB)
    try:
        c = conn.cursor()
        c.execute("SELECT tree_id FROM trees WHERE institution = ?", (institution_name,))
        existing_ids = [id[0] for id in c.fetchall() if id[0] and str(id[0]).startswith(prefix)]
        
        if not existing_ids:
            return f"{prefix}001"
        
        # Extract numeric parts and find max
        numeric_parts = []
        for id in existing_ids:
            match = re.search(r'\d+$', str(id))
            if match:
                numeric_parts.append(int(match.group()))
        
        if numeric_parts:
            max_num = max(numeric_parts)
            return f"{prefix}{max_num + 1:03d}"
        else:
            return f"{prefix}001"
    except Exception as e:
        st.error(f"Error generating tree ID: {e}")
        return f"{prefix}{int(time.time())}"
    finally:
        conn.close()

def generate_qr_code(tree_id):
    """
    Generate QR code for a tree ID and save it as PNG.
    
    Args:
        tree_id: Unique tree identifier
        
    Returns:
        Tuple of (base64_encoded_image, file_path)
    """
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(tree_id)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save as file
    file_path = QR_CODE_DIR / f"{tree_id}_qr.png"
    img.save(file_path)
    
    # Also create base64 encoded version for display
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    
    return img_str, str(file_path)

def calculate_co2(scientific_name, rcd=None, dbh=None):
    """
    Calculate CO2 sequestration based on tree measurements.
    
    Args:
        scientific_name: Scientific name of tree species
        rcd: Root collar diameter in cm
        dbh: Diameter at breast height in cm
        
    Returns:
        CO2 sequestration in kg
    """
    conn = sqlite3.connect(SQLITE_DB)
    try:
        species_data = pd.read_sql("SELECT * FROM species", conn)
        try:
            density = species_data[species_data["scientific_name"] == scientific_name]["wood_density"].values[0]
        except:
            density = 0.6  # Default density if species not found
        
        if dbh is not None and dbh > 0:
            agb = 0.0509 * density * (dbh ** 2.5)
        elif rcd is not None and rcd > 0:
            agb = 0.042 * (rcd ** 2.5)
        else:
            return 0.0
            
        bgb = 0.2 * agb
        carbon = 0.47 * (agb + bgb)
        return round(carbon * 3.67, 2)  # Convert carbon to CO2
    except Exception as e:
        st.error(f"Error calculating CO2: {e}")
        return 0.0
    finally:
        conn.close()

def save_tree_from_kobo_submission(kobo_data):
    """
    Process a KoBo submission and save it to the database.
    
    Args:
        kobo_data: Dictionary containing KoBo form submission
        
    Returns:
        Tuple of (success, tree_id, qr_code_path)
    """
    # Map KoBo fields to database fields
    mapped_data = map_kobo_to_database_fields(kobo_data)
    
    # Generate tree ID
    tree_id = generate_tree_id(mapped_data["institution"])
    mapped_data["tree_id"] = tree_id
    
    # Calculate CO2 sequestration
    mapped_data["co2_kg"] = calculate_co2(
        mapped_data["scientific_name"], 
        mapped_data["rcd_cm"], 
        mapped_data["dbh_cm"]
    )
    
    # Generate QR code
    qr_code_base64, qr_code_path = generate_qr_code(tree_id)
    mapped_data["qr_code"] = qr_code_base64
    
    # Save to database
    conn = sqlite3.connect(SQLITE_DB)
    try:
        c = conn.cursor()
        
        # Create placeholders and values for SQL insert
        placeholders = ", ".join(["?"] * len(mapped_data))
        columns = ", ".join(mapped_data.keys())
        values = tuple(mapped_data.values())
        
        c.execute(f"INSERT INTO trees ({columns}) VALUES ({placeholders})", values)
        
        # Also add to monitoring history
        c.execute("""
            INSERT INTO monitoring_history (
                tree_id, monitor_date, monitor_status, monitor_stage, 
                rcd_cm, dbh_cm, height_m, co2_kg, notes, monitor_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tree_id,
            mapped_data["date_planted"],
            "Alive",
            mapped_data["tree_stage"],
            mapped_data["rcd_cm"],
            mapped_data["dbh_cm"],
            mapped_data["height_m"],
            mapped_data["co2_kg"],
            mapped_data["monitor_notes"],
            mapped_data["student_name"]
        ))
        
        conn.commit()
        return True, tree_id, qr_code_path
    except Exception as e:
        conn.rollback()
        st.error(f"Database error: {e}")
        return False, None, None
    finally:
        conn.close()

def check_for_new_submissions(user_email=None):
    """
    Check for new submissions from KoBo and process them.
    
    Args:
        user_email: Optional email to filter submissions by
        
    Returns:
        List of processed submission results
    """
    # Get recent submissions (last 24 hours)
    submissions = get_recent_kobo_submissions(24)
    
    results = []
    for submission in submissions:
        # If user_email is provided, filter submissions
        if user_email and submission.get("email") != user_email:
            continue
            
        # Check if this submission has already been processed
        # by looking for its tree_id in the database
        submission_id = submission.get("_id")
        
        conn = sqlite3.connect(SQLITE_DB)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM trees WHERE monitor_notes LIKE ?", (f"%{submission_id}%",))
        already_processed = c.fetchone()[0] > 0
        conn.close()
        
        if not already_processed:
            # Add submission ID to monitor notes for future reference
            if "notes" not in submission:
                submission["notes"] = ""
            submission["notes"] += f" [Submission ID: {submission_id}]"
            
            # Process and save the submission
            success, tree_id, qr_code_path = save_tree_from_kobo_submission(submission)
            
            if success:
                results.append({
                    "tree_id": tree_id,
                    "qr_code_path": qr_code_path,
                    "submission_time": submission.get("_submission_time", ""),
                    "institution": submission.get("institution", ""),
                    "local_name": submission.get("local_name", "")
                })
    
    return results

def plant_a_tree_section():
    """
    Main function for the Plant a Tree section with KoBo integration.
    """
    st.markdown("<h1 class='header-text'>🌱 Plant a Tree</h1>", unsafe_allow_html=True)
    
    # Check if user is logged in
    if "user" not in st.session_state:
        st.warning("Please log in to plant a tree.")
        if st.button("Go to Login"):
            st.session_state.show_login = True
            st.rerun()
        return
    
    # Only certain user types can plant trees
    user_type = st.session_state.user.get("user_type", "")
    if user_type not in ["admin", "school", "field"]:
        st.error("You don't have permission to plant trees. Please contact your administrator.")
        return
    
    # Main planting workflow
    st.markdown("""
    <div class="card">
        <h3>Plant a Tree and Track Its Growth</h3>
        <p>Use our KoBo Toolkit integration to easily record tree plantings with accurate location data.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Step 1: Launch KoBo form
    if "kobo_form_launched" not in st.session_state:
        form_url = launch_kobo_form()
    
    # Step 2: Check for submissions after form completion
    if st.session_state.get("check_for_submission", False):
        with st.spinner("Checking for your submission..."):
            # In a real app, you might filter by user email
            user_email = None  # Could be st.session_state.user.get("email")
            results = check_for_new_submissions(user_email)
            
            if results:
                st.success(f"Found {len(results)} new tree planting submissions!")
                
                for result in results:
                    st.markdown(f"""
                    <div class="card">
                        <h4>🌳 Tree Planted Successfully!</h4>
                        <p><strong>Tree ID:</strong> {result['tree_id']}</p>
                        <p><strong>Species:</strong> {result['local_name']}</p>
                        <p><strong>Institution:</strong> {result['institution']}</p>
                        <p><strong>Planted on:</strong> {result['submission_time']}</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Display QR code
                    if result['qr_code_path']:
                        st.image(result['qr_code_path'], caption=f"QR Code for Tree {result['tree_id']}")
                        st.download_button(
                            label="Download QR Code",
                            data=open(result['qr_code_path'], "rb").read(),
                            file_name=f"{result['tree_id']}_qr.png",
                            mime="image/png"
                        )
                
                # Reset the form launch state
                if st.button("Plant Another Tree"):
                    for key in ['kobo_form_launched', 'check_for_submission']:
                        if key in st.session_state:
                            del st.session_state[key]
                    st.rerun()
            else:
                st.warning("No new submissions found. Please complete the KoBo form.")
                if st.button("I've Completed the Form", key="retry_check"):
                    st.rerun()
                    
                if st.button("Start Over"):
                    for key in ['kobo_form_launched', 'check_for_submission']:
                        if key in st.session_state:
                            del st.session_state[key]
                    st.rerun()

# Function to manually check for submissions (for testing)
def manual_submission_check():
    st.subheader("Manual Submission Check")
    if st.button("Check for New Submissions"):
        with st.spinner("Checking for submissions..."):
            results = check_for_new_submissions()
            
            if results:
                st.success(f"Found {len(results)} new submissions!")
                for result in results:
                    st.write(f"Tree ID: {result['tree_id']}")
                    st.write(f"QR Code: {result['qr_code_path']}")
            else:
                st.info("No new submissions found.")

# For testing purposes
if __name__ == "__main__":
    st.set_page_config(page_title="KoBo Integration Test", layout="wide")
    st.title("KoBo Integration Test")
    
    # Initialize session state for testing
    if "user" not in st.session_state:
        st.session_state.user = {
            "username": "test_user",
            "user_type": "admin",
            "institution": "Test Institution"
        }
    
    plant_a_tree_section()
    
    # Add manual check option for testing
    with st.expander("Developer Tools"):
        manual_submission_check()
